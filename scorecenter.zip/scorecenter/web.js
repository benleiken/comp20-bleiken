var express = require("express");
var app = express();

app.configure(function () {
    app.use(express.methodOverride());
    app.use(express.bodyParser());
    app.use(express.logger());
    app.use(function(req, res, next) {
      res.header("Access-Control-Allow-Origin", "*");
      res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE');
      res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
      if('OPTIONS' == req.method){
        res.send(200);
      }
      else next();
    });
    app.use(app.router);
});

app.set('title', 'ScoreCenter');

// Mongo initialization
var databaseUrl = process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var collections = ["scores"]
var db= require("mongojs").connect(databaseUrl, collections);


app.get('/', function (request, response, next) {
	response.set('Content-Type', 'text/html');
        db.scores.find({}).sort({game_title:1}, function(err, scores) {
          if( err || !scores) console.log("No scores");
          else response.send(scores);
    });
});

app.get('/highscores.json', function(request, response,next) {
	response.set('Content-Type', 'text/json');
        var title = request.query["game_title"];
        if(!title){
            console.log("No scores");
            response.send("Error");
        }
        else{
        db.scores.find({game_title: title}, {score: 1}).limit(10).sort({score:-1}, function(err, scores) {
          if( err || !scores) response.send("Error");
          else response.send(scores);
    });
        }

});

app.get('/usersearch', function(request, response, next){
  response.set('Content-Type', 'text/html');
  response.send("<form action='/search' method='get'><input type='text' name='input' id='input'> <input type='submit' id='submit'></form>");

});

app.get('/search', function(request, response, next){
  inp = request.query['input'];
  console.log(inp);
  response.set('Content-Type', 'text/html');
  db.scores.find({username: inp}, {score: 1, username: 1}).limit(10, function(err, scores) {
        if( err || !scores) console.log("No scores");
        else response.send(scores);
   });

});



app.post('/submit.json', function(request, response, next) {
  input = request.body;
  if(!input ||!input.game_title || !input.username || !input.score){
    console.log("error");
  }
  else{
  d = new Date();
  input.created_at = d.toString();
  db.scores.save(input);
  response.send(201);
  }
});


var port = process.env.PORT || 5000;
app.listen(port, function() {
});

